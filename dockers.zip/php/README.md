## Steps to run app

```sh
composer install

php bin/chat-server.ph
```

Some example Sites
- https://medium.com/@nihon_rafy/create-a-websocket-server-with-symfony-and-ratchet-973a59e2df94
